HORTA DO BEZADA

Como usar:
1. Abra o arquivo index.html no navegador.
2. O site já funciona sem internet para o catálogo e carrinho.
3. Para receber pedidos no WhatsApp, abra script.js e troque:
   const telefone = "5551999999999";
   pelo seu número com código do Brasil + DDD, somente números.

Exemplo:
const telefone = "55519988887777";

Preços de exemplo:
- Alface: R$ 4,00/maço
- Couve: R$ 4,00/maço
- Rúcula: R$ 4,00/maço
- Cebolinha: R$ 3,00/maço
- Salsinha: R$ 3,00/maço

Você pode alterar os preços no início do arquivo script.js.
