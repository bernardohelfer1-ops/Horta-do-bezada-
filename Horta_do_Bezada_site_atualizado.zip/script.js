const produtos = [
  { nome: "Alface", preco: 4.00, emoji: "🥬" },
  { nome: "Couve", preco: 4.00, emoji: "🌿" },
  { nome: "Rúcula", preco: 4.00, emoji: "🥗" },
  { nome: "Cebolinha", preco: 3.00, emoji: "🧅" },
  { nome: "Salsinha", preco: 3.00, emoji: "🌱" }
];

let carrinho = [];

const dinheiro = valor =>
  valor.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

function mostrarProdutos() {
  const area = document.getElementById("produtos");
  area.innerHTML = produtos.map((p, i) => `
    <article class="card">
      <div class="foto">${p.emoji}</div>
      <h3>${p.nome}</h3>
      <p>Fresquinha da horta</p>
      <div class="preco">${dinheiro(p.preco)} / maço</div>
      <button class="add" onclick="adicionar(${i})">Adicionar ao pedido</button>
    </article>
  `).join("");
}

function adicionar(index) {
  const produto = produtos[index];
  const item = carrinho.find(x => x.nome === produto.nome);
  if (item) item.qtd++;
  else carrinho.push({ ...produto, qtd: 1 });
  atualizarCarrinho();
}

function remover(index) {
  carrinho[index].qtd--;
  if (carrinho[index].qtd <= 0) carrinho.splice(index, 1);
  atualizarCarrinho();
}

function atualizarCarrinho() {
  const area = document.getElementById("carrinho");

  if (!carrinho.length) {
    area.innerHTML = '<p class="vazio">Seu carrinho está vazio.</p>';
  } else {
    area.innerHTML = carrinho.map((item, i) => `
      <div class="item">
        <span>${item.emoji} ${item.nome} × ${item.qtd}</span>
        <span>
          ${dinheiro(item.preco * item.qtd)}
          <button onclick="remover(${i})" title="Remover">➖</button>
        </span>
      </div>
    `).join("");
  }

  const total = carrinho.reduce((s, x) => s + x.preco * x.qtd, 0);
  document.getElementById("total").textContent = dinheiro(total);
}

document.getElementById("whatsapp").addEventListener("click", () => {
  if (!carrinho.length) {
    alert("Adicione pelo menos um produto ao pedido.");
    return;
  }

  const linhas = carrinho.map(x =>
    `• ${x.nome}: ${x.qtd} maço(s) — ${dinheiro(x.preco * x.qtd)}`
  );

  const total = carrinho.reduce((s, x) => s + x.preco * x.qtd, 0);

  const mensagem =
    `Olá! 🌱 Quero fazer um pedido na Horta do Bezada:\n\n` +
    linhas.join("\n") +
    `\n\n💰 Total: ${dinheiro(total)}\n\nComo posso combinar a entrega/retirada?`;

  // TROQUE pelo seu número com DDI + DDD, somente números.
  const telefone = "555180103629";
  window.open(`https://wa.me/${telefone}?text=${encodeURIComponent(mensagem)}`, "_blank");
});

mostrarProdutos();
atualizarCarrinho();
